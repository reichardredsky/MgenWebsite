document.addEventListener('DOMContentLoaded', () => {
  const carouselWrap = document.getElementById('mgen-carousel');
  const carouselContainer = carouselWrap.querySelector('.carousel--container');
  const carouselItems = carouselContainer.querySelectorAll('.carousel--item');
  const itemCount = carouselItems.length;
  let currentIndex = 1;
  let moveLeft = true; // Track alternating movement
  const gapX = 0;
  const itemsToShow = 3;
  const containerWidth = carouselContainer.getBoundingClientRect().width;
  const itemSpace = (containerWidth / (itemsToShow));

  // const itemWidth = containerWidth / itemsToShow;
  const itemWidth = 266;

  // Initial positioning
  const positionItems = () => {
    carouselItems.forEach((item, index) => {
      const offset = (currentIndex + index) % itemCount;
      // console.log(item.getClie)
      item.style.width = `${(itemWidth - gapX)}px`;
      item.style.left = `${(gapX/2)}px`;
      item.style.zIndex = (offset == 1) ? '10' : index;
      item.style.transform = `translateX(${(offset*(itemSpace))}px) ${offset == 1 ? 'scale(1.1)' : 'scale(1)'}`;
      // item.style.transform = `translateX(${(offset*(itemSpace))}px)`;
    });
  };

  positionItems();

  // Rotation logic
  setInterval(() => {
    
    // currentIndex = (currentIndex + 1) & itemCount;
    currentIndex = (currentIndex + 1);

    if (currentIndex >= itemCount) {
      currentIndex = 0;
    }

    console.log(currentIndex);

    positionItems();
  }, 2000);
});
